package com.example.seoulairqualityapi.openAPI;


import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import retrofit2.Retrofit;
import retrofit2.converter.jackson.JacksonConverterFactory;

import java.io.IOException;

@Slf4j    //logger
@Component  //상속을 받기위한 클래스(개발자가 직접 작성한 class를 빈으로 등록하기 위함)
public class RetrofitConfig {
    private final OpenApiInterface openApiInterface;

    public RetrofitConfig(@Value("${apis.data.go.kr.6260000}") String baseUrl) {
        ObjectMapper objectMapper = new ObjectMapper();
        objectMapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);

        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl(baseUrl)
                .addConverterFactory(JacksonConverterFactory.create(objectMapper))
                .build();

        this.openApiInterface = retrofit.create(OpenApiInterface.class);
    }

    public OpenApiDto getAirQuality(){
        try {
            var call = openApiInterface.getAirQuality();
            var response = call.execute().body();

            if (response == null || response.getListavgofseoulairqualityservice().getResult() == null){
                throw new RuntimeException("응답값 존재안함");
            }

            if(response.getListavgofseoulairqualityservice().getResult().isSuccess()){
                log.info(response.toString());
                return response;
            }
            throw new RuntimeException("응답이 올바르지 않습니다 header =" +response.getListavgofseoulairqualityservice().getResult().getCode());

        } catch (IOException e) {
            e.printStackTrace();
            log.error(e.getMessage(), e);
            throw new RuntimeException("api에러 발생 errorMessage=" + e.getMessage());
        }
    }

}
